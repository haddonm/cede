## ----setup, include=FALSE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(
	echo = TRUE,
	message = FALSE,
	warning = FALSE)
options(knitr.kable.NA = "",
        knitr.table.format = "pandoc")

options("show.signif.stars"=FALSE,"stringsAsFactors"=FALSE,
        "max.print"=50000,"width"=240)

library(cede)
suppressPackageStartupMessages(library(knitr))


## ----spscontents, echo=TRUE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

data(sps)
head(sps)
properties(sps)

## ----echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
round(tapsum(sps,"catch_kg","Year","Month"),2)

## ----echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
tapsum(sps,"catch_kg","Year","Zone")

## ----echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
effbyyr <- tapsum(sps,"Effort","Year","Zone",div=1.0)
effbyyr

## ----ploteffort, echo=TRUE, fig.width=7,fig.height=4.5,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# plotprep(width=7,height=4.5)
ymax <- max(effbyyr,na.rm=TRUE)
label <- colnames(effbyyr)
yrs <- as.numeric(rownames(effbyyr))
par(mfrow=c(1,1),mai=c(0.45,0.45,0.05,0.05)) 
par(cex=0.85, mgp=c(1.35,0.35,0), font.axis=7,font=7,font.lab=7) 
plot(yrs,effbyyr[,label[1]],type="l",lwd=2,col=1,ylim=c(0,ymax),
     ylab="Total Effort (Hours) by Zone per Year",xlab="",
     panel.first=grid())
lines(yrs,effbyyr[,label[2]],lwd=2,col=2)
lines(yrs,effbyyr[,label[3]],lwd=2,col=3)
# the "topright"" can also be "bottomright", "bottom", "bottomleft", "left", 
# # "topleft", "top", "right" and "center". Alternatively one can give an
# x and a y location, see ?legend, which is a function from graphics package
legend("topright",label,col=c(1,2,3),lwd=3,bty="n",cex=1.25)


## ----echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
tapsum(sps,"catch_kg","Year","DayNight")

## ----catchbyvessel, echo=TRUE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
cbv <- tapsum(sps,"catch_kg","Vessel","Year") # often more vessels than years
total <- rowSums(cbv,na.rm=TRUE)
cbv1 <- cbv[order(total),]   # sort by total catch smallest catches first
round(cbv1,2)


## ----yeasrbubble, fig.width=7,fig.height=5,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# plotprep(width=8,height=6) # not needed in the vignette
to <- turnover(cbv1)
yearBubble(cbv1,ylabel="sqrt(catch-per-vessel)",diam=0.125,txt=c(2,3,4,5),
           hline=TRUE)


## ----echo = TRUE------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
print(to)

## ----includeCPUE, echo=TRUE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
sps$CE <- NA     # make explicit space in the data.frame
sps$LnCE <- NA
pick <- which((sps$catch_kg > 0) & (sps$Effort > 0))
sps$CE[pick] <- sps$catch_kg[pick]/sps$Effort[pick]
sps$LnCE[pick] <- log(sps$CE[pick])   # natural log-transformation
# categorize Depth
range(sps$Depth,na.tm=TRUE)  # to aid selection of depth class width
sps$DepCat <- NA
sps$DepCat <- trunc(sps$Depth/25) * 25
table(sps$DepCat)


## ----cebyyr, echo=TRUE, fig.width=7,fig.height=6,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

outH <- histyear(sps,Lbound=-1.75,Rbound=8.5,inc=0.25,pickvar="LnCE",
                 years="Year",varlabel="log(CPUE)",plots=c(4,3))


## ----depthbyyr, echo=TRUE, fig.width=7,fig.height=6,fig.align="center"------------------------------------------------------------------------------------------------------------------------------------------------------------------------

outH <- histyear(sps,Lbound=0,Rbound=375,inc=12.5,pickvar="Depth",
                 years="Year",varlabel="Depth (m)",plots=c(4,3),vline=120)


## ----depthbyyr2, echo=TRUE, fig.width=7,fig.height=6,fig.align="center"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

outH <- histyear(sps,Lbound=0,Rbound=10,inc=0.25,pickvar="Effort",
                 years="Year",varlabel="Effort ('000s Hrs)",plots=c(4,3),
                 vline=NA)


## ----catchvseffort, fig.width=7,fig.height=5,fig.align="center"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,1),mai=c(0.45,0.45,0.05,0.05)) 
par(cex=0.85, mgp=c(1.35,0.35,0), font.axis=7,font=7,font.lab=7)  
plot(sps$Effort,sps$catch_kg,type="p",pch=16,col=rgb(1,0,0,1/5),
     ylim=c(0,500),xlab="Effort (Hrs)",ylab="Catch (Kg)")
abline(h=0.0,col="grey")


## ----sketchmap1, echo=TRUE, fig.width=7,fig.height=5.5,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------
leftlong <- 143.0;  rightlong <- 150.0
uplat <- -40.0;  downlat <- -44.6
plotaus(leftlong,rightlong,uplat,downlat,gridon=1.0)
addpoints(sps,intitle="Location of Catches")
plotLand(incol="blue")


## ----sketchmap2, echo=TRUE, fig.width=7,fig.height=5.5,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------
leftlong <- 143.0;  rightlong <- 150.0
uplat <- -40.0;  downlat <- -44.6
plotaus(leftlong,rightlong,uplat,downlat,gridon=1.0)
plotpolys(sps,leftlong,rightlong,uplat,downlat,gridon=0.2,leg="left",
          intitle="0.2 degree squares",mincount=2,namecatch="catch_kg")
plotLand(incol="pink")


## ----makecategorical, echo=TRUE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
properties(sps)
labelM <- c("Year","Zone","Vessel","Month","DayNight","DepCat")
sps1 <- makecategorical(labelM,sps)
properties(sps1)


## ----makeamodel, echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
labelM <- c("Year","Zone","Vessel","Month","DayNight","DepCat")
sps1 <- makecategorical(labelM,sps)
mod <- makeonemodel(labelM)
mod
class(mod)

## ----standardize, echo=TRUE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
labelM <- c("Year","Zone","Vessel","Month","DayNight","DepCat")
sps1 <- makecategorical(labelM,sps)
mod <- makeonemodel(labelM)
out <- dosingle(mod,sps1)   # no interaction terms this time
str(out,max.level=1)


## ----ananova, echo=TRUE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

anova(out$optModel)

## ----out_results, echo=TRUE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
cbind(out$Results,out$StErr)

## ----getfact, echo=TRUE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

round(getfact(out$optModel,"Year"),5)

## ----cpueplot, echo=TRUE, fig.width=7,fig.height=4.5,fig.align="center"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# plotprep(width=7,height=4.5)
plotstand(out,bars=TRUE)


## ----cpueplot2, echo=TRUE, fig.width=7,fig.height=4.5,fig.align="center"----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# plotprep(width=7,height=4.5)
geom <-geomean(sps$CE)
plotstand(out,bars=TRUE,geo=geom)


## ----diagnostic1, echo=TRUE, fig.width=7, fig.height=6----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(2,2),mai=c(0.45,0.45,0.05,0.05),oma=c(0.0,0,0.0,0.0)) 
par(cex=0.85, mgp=c(1.35,0.35,0), font.axis=7,font=7,font.lab=7) 
plot(out$optModel)


## ----diagnostic2, echo=TRUE, fig.width=7, fig.height=5----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

par(mai=c(0.45,0.45,0.15,0.05),font.axis=7)
qqdiag(out$optModel,plotrug=TRUE,)



## ----contributions, echo=TRUE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# first make a matrix to hold the results
labelM <- c("Year","Zone","DepCat","Vessel","Month","DayNight")
columns <- c("adjR2","incR2","RSS","MSS","Npar","nobs","AIC")
nummod <- length(labelM)
yrs <- sort(unique(sps$Year))
nyrs <- length(yrs)
results <- as.data.frame(matrix(0,nrow=nummod,ncol=length(columns),
                         dimnames=list(labelM,columns)))
trends <- as.data.frame(matrix(0,nrow=nyrs,ncol=length(labelM),
                         dimnames=list(yrs,labelM)))
for (i in 1:nummod) {  # sequentially build the models
   mod <- makeonemodel(labelM[1:i])  # When i = 1 LnCE ~ Year
   out <- dosingle(mod,sps1)
   trends[,i] <- out$Results[,"optimum"]
   outsum <- summary(out$optModel)
   aov <- anova(out$optModel)    #  Extract a range of results 
   RSS <- tail(aov$"Sum Sq",1)
   df <- aov$Df
   nobs <- sum(df) + 1
   numfact <- length(df) - 1
   npars <- sum(df[1:numfact]) + 1
   AIC <- nobs * log(RSS/nobs) + (2 * npars)
   results[i,] <- c(outsum$adj.r.squared,NA,RSS,sum(aov$"Sum Sq") - RSS,npars,nobs,AIC)
}
results[2:nummod,"incR2"] <- results[2:nummod,"adjR2"]-results[1:(nummod-1),"adjR2"]
round(results,4)
round(trends,4)


## ----gammaerrors, echo=TRUE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

labelM <- c("Year","Zone","Vessel","Month","DayNight","DepCat","Month:Zone")
sps1 <- makecategorical(labelM,sps)
mod <- makeonemodel(labelM,dependent="CE")

model4 <- glm(mod,family=Gamma(link="log"),data=sps1)
m4 <- summary(model4)$coefficients  # combine these with empty first year
yrval <- rbind(c(0,0,0,0),m4[grep("Year",rownames(m4)),])
# backtransform the gamma model parameter using a simple 'exp' function
# use the function scaleCE to rescale the results t a mean of 1.0 to
# ease comparison with other trends.
gamres <- cbind(yrval,exp(yrval[,"Estimate"]),scaleCE(exp(yrval[,"Estimate"])))
rownames(gamres) <- yrs # 2003:2014 from  teh chunk immediately above
round(gamres,4)


## ----compareCPUE, echo=TRUE,fig.width=7,fig.height=4.5,fig.align="center"---------------------------------------------------------------------------------------------------------------------------------------------------------------------
plotstand(out,bars=TRUE)
lines(2003:2014,gamres[,6],lwd=2,col=4)


## ----useGAM, echo=TRUE------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# install and call these R packages and their dependencies
library(nlme)
library(mgcv)
library(gamm4)
# note the use of gam rather than lm or glm (see the examples in ?gam for more
# details. 
modelGam <- gam(LnCE ~ s(Long,Lat) + Year + Zone + Vessel + Month + 
                   DayNight + DepCat, data = sps1)
anova(modelGam)


## ----useGAMnoZone, echo=TRUE------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
modelGam <- gam(LnCE ~ s(Long,Lat) + Year + Vessel + Month + 
                   DayNight + DepCat, data = sps1)
anova(modelGam)


## ----getresults, echo=TRUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

answer <- getfact(modelGam,"Year")
opti <- answer[,"Scaled"]
round(answer,5)

## ----plotgam, fig.width=5,fig.height=8,fig.align="center"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#plotprep(width=4.5,height=7)
 plot(modelGam,ylim=c(-44.5,-40),xlim=c(143.5,146.5),se=FALSE,xlab="",ylab="")
 title(ylab=list("Latitude", cex=1.0, font=7),
       xlab=list("Longitude", cex=1.0, font=7))
 plotLand("pink")


## ----gamvsglm, fig.width=7,fig.height=4.5,fig.align="center"----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#plotprep(width=7,height=4.5)
plotstand(out,bars=TRUE)
lines(facttonum(out$years),opti,col=4,lwd=2)
legend("bottomleft",c("GLM","GAM"),col=c(1,4),lwd=3,bty="n",cex=1.2)


